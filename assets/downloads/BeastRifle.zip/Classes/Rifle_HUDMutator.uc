////////////////////////////////////////////////////////////////////////////////
//
// Rifle HUD MUTATOR
//
////////////////////////////////////////////////////////////////////////////////
//
// Contact: spawnkiller@1utlimatesnipingzone.com
//
// Website: www.1ultimatesnipingzone.com
//
// Coded for UTPURERC6E compliance by TNSe
//
// This will allow custom crosshair to work with UTPURERC6D and UTPURERC6E
//
////////////////////////////////////////////////////////////////////////////////

class Rifle_HUDMutator expands Mutator;

var PlayerPawn HUDOwner;

simulated event PostRender( canvas Canvas )
{
	if (HUDOwner != None && HUDOwner.Weapon != None)
	{
		// if (Owner.Weapon.IsA('CustomSniperRifle'))	// You may want to enable this.
		HUDOwner.Weapon.PostRender(Canvas);
	}
}

defaultproperties
{
}
