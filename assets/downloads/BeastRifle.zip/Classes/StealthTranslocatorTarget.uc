//=============================================================================
// TranslocatorTarget.
//=============================================================================
class StealthTranslocatorTarget extends TranslocatorTarget;


defaultproperties
{
    ImpactSound=None
    AmbientSound=None
}
