////////////////////////////////////////////////////////////////////////////////
//
// CustomBullets for the JUC Clan
//      by: :[lol]:WalknBullseye
//    Recompiled by .:TOAO:. {-KILLER-}
//
//
//
//
////////////////////////////////////////////////////////////////////////////////

class CustomBullets extends TournamentAmmo;

#EXEC texture IMPORT name=BulletBox FILE=Textures\BulletBox.bmp GROUP=Skins

defaultproperties
{
    AmmoAmount=250
    MaxAmmo=500
    UsedInWeaponSlot(9)=1
    PickupMessage="You got a box of {Beast} Rifle rounds."
    ItemName="Box of Rifle Rounds"
    PickupViewMesh=LodMesh'Botpack.BulletBoxM'
    MaxDesireability=0.24
    Icon=Texture'UnrealI.Icons.I_RIFLEAmmo'
    Mesh=LodMesh'Botpack.BulletBoxM'
    MultiSkins(0)=Texture'Skins.BulletBox'
    MultiSkins(1)=Texture'Skins.BulletBox'
    MultiSkins(2)=Texture'Skins.BulletBox'
    MultiSkins(3)=Texture'Skins.BulletBox'
    MultiSkins(4)=Texture'Skins.BulletBox'
    MultiSkins(5)=Texture'Skins.BulletBox'
    MultiSkins(6)=Texture'Skins.BulletBox'
    MultiSkins(7)=Texture'Skins.BulletBox'
    CollisionRadius=15.00
    CollisionHeight=10.00
    bCollideActors=True
}
