////////////////////////////////////////////////////////////////////////////////
//
// CustomSniperRifle.
//
////////////////////////////////////////////////////////////////////////////////
//
// #exec TEXTURE IMPORT NAME=Rifle2A FILE=Textures\Rifle2A.pcx GROUP=Rifle
//
// #exec TEXTURE IMPORT NAME=Rifle2B FILE=Textures\Rifle2B.pcx GROUP=Rifle
//
// #exec TEXTURE IMPORT NAME=crosshair FILE=textures\crosshair.pcx FLAGS=2 MIPS=OFF
//
// MultiSkins[0] = Texture'_MUTATORS.Rifle.Rifle.Rifle2A';
//
// MultiSkins[1] = Texture'_MUTATORS.Rifle.Rifle.Rifle2B';
//
// MultiSkins(0)=Texture'_MUTATORS.Rifle.Rifle2A'
//
// MultiSkins(1)=Texture'_MUTATORS.Rifle.Rifle2B'
//
// Place all Custom Textures in the Textures Folder
//
// Repalce with your custom textures or remove all lines above
//
////////////////////////////////////////////////////////////////////////////////
//
// #exec AUDIO IMPORT FILE="sounds\FIRE.wav" NAME="FIRE" GROUP="Rifle"
//
// FireSound=Sound'Rifle.FIRE
//
// All Gun Fire Sounds = FIRE.wav place in Sounds Folder
//
// You must have a sound to compile this gun or you will have no fire sound
//
// All Crosshaires = Crosshair place in Textures Folder
//
// All Rifle textures = Rifle2A Rilfe2B  place in Textures Folder
//
// TOAO     //// Replace all with your folder name
//
// TOAO     //// Replace all with your clan name
//
////////////////////////////////////////////////////////////////////////////////

class CustomSniperRifle expands TournamentWeapon config (BeastRifle);

#EXEC AUDIO IMPORT name=FIRE FILE=sounds\Fire.wav GROUP=Rifle

#EXEC texture IMPORT name=Rifle2A FILE=Textures\Rifle2A.bmp GROUP=Rifle
#EXEC texture IMPORT name=Rifle2B FILE=Textures\Rifle2B.bmp GROUP=Rifle
#EXEC texture IMPORT name=Rifle2C FILE=Textures\Rifle2C.bmp GROUP=rifle
#EXEC texture IMPORT name=Rifle2D FILE=Textures\Rifle2D.bmp GROUP=rifle
#EXEC texture IMPORT NAME=crossretul FILE=Textures\crossretul.bmp MIPS=0 FLAGS=2

var int NumFire;
var name FireAnims[5];
var vector OwnerLocation;
var float StillTime, StillStart;
var bool bZoom;
var config color CColor;




simulated event PostNetBeginPlay()
{
   local Rifle_HUDMutator crosshair;
   local PlayerPawn HUDOwner;

   Super.PostNetBeginPlay();

   // If owner is the local player, check that the HUD Mutator exists. Also check for the presense of a bbPlayer (UTPure enabled)
   HUDOwner = PlayerPawn(Owner);
   if (HUDOwner != None && HUDOwner.IsA('bbPlayer') && HUDOwner.myHUD != None)
   {
      ForEach AllActors(Class'Rifle_HUDMutator', crosshair)
         break;
      if (crosshair == None)
      {
         crosshair = Spawn(Class'Rifle_HUDMutator', Owner);
         crosshair.RegisterHUDMutator();
         crosshair.HUDOwner = HUDOwner;
      }
   }
}

simulated function PostRender( canvas Canvas )
{
   local PlayerPawn P;
   //local float HudScale;
	local float Scale;





	Super.PostRender(Canvas);
	P = PlayerPawn(Owner);
        




	if ( (P != None) && (P.DesiredFOV != P.DefaultFOV) )
	{
		bOwnsCrossHair = true;
		scale = (Canvas.ClipX/1024);

		if ( Level.bHighDetailMode )
			Canvas.Style = ERenderStyle.STY_Translucent;
		else
			Canvas.Style = ERenderStyle.STY_Normal;


		//HudScale will determine the scaling on the Reticle. We don't want
		//it any smaller than the regular size, and too much scaling will
		//make it look like crap. Keep it to 1<=HudScale<=2. Start scaling
		//at 1024 horizontal resolution.
		/*HudScale = Canvas.ClipX/1500;
		if (HudScale < 1)

			HudScale = 1;
        else if (HudScale > 2)

			    HudScale = 2;





		Canvas.SetPos((Canvas.ClipX/2)-(HudScale*256), (Canvas.ClipY/2)-(HudScale*256));
		Canvas.DrawIcon( texture 'crossretul' , HudScale);
		Canvas.DrawIcon( texture 'crossretur' , HudScale);
		Canvas.SetPos((Canvas.ClipX/2)-(HudScale*256), Canvas.ClipY/2);
		Canvas.DrawIcon( texture 'crossretbl' , HudScale);
		Canvas.DrawIcon( texture 'crossretbr' , HudScale);  */

        Canvas.SetPos(0.5 * Canvas.ClipX - 128 * Scale, 0.5 * Canvas.ClipY - 128 * scale );
        Canvas.DrawColor = CColor;
		Canvas.DrawIcon(Texture'crossretul', Scale);




	}
	else
		bOwnsCrossHair = false;
}

function float RateSelf( out int bUseAltMode )
{
   local float dist;

   if ( AmmoType.AmmoAmount <=0 )
      return -2;

   bUseAltMode = 0;
   if ( (Bot(Owner) != None) && Bot(Owner).bSniping )
      return AIRating + 1.15;
   if (  Pawn(Owner).Enemy != None )
   {
      dist = VSize(Pawn(Owner).Enemy.Location - Owner.Location);
      if ( dist > 1200 )
      {
         if ( dist > 2000 )
            return (AIRating + 0.75);
         return (AIRating + FMin(0.0001 * dist, 0.45));
      }
   }
   return AIRating;
}

// set which hand is holding weapon
function setHand(float Hand)
{
   Super.SetHand(Hand);
   if ( Hand == 1 )
   {
      Mesh = mesh(DynamicLoadObject("Botpack.Rifle2mL", class'Mesh'));
   }
   else
   {
      Mesh = mesh'Rifle2m';
      MultiSkins[0] = texture'BeastRifle.rifle.Rifle2A';
      MultiSkins[1] = texture'BeastRifle.rifle.Rifle2B';
      MultiSkins[2] = texture'BeastRifle.rifle.Rifle2C';
      MultiSkins[3] = texture'BeastRifle.rifle.Rifle2D';
   }
}
/*
function DropFrom(vector StartLocation)
{
   Destroy();
}
*/
simulated function PlayFiring()
{
   local int r;

   PlayOwnedSound(FireSound, SLOT_None, Pawn(Owner).SoundDampening*3.0);
   if ( (Owner.Physics != PHYS_Falling && Owner.Physics != PHYS_Swimming && Pawn(Owner).bDuck != 0)
      || Owner.Velocity == 0 * Owner.Velocity )
      PlayAnim(FireAnims[/*Rand(5)*/4],3 + 3 * FireAdjust, 0.05);
   else
      PlayAnim(FireAnims[Rand(5)],0.3 + 0.3 * FireAdjust, 0.05);

   if ( (PlayerPawn(Owner) != None)
      && (PlayerPawn(Owner).DesiredFOV == PlayerPawn(Owner).DefaultFOV) )
      bMuzzleFlash++;
}

simulated function bool ClientAltFire( float Value )
{
   GotoState('Zooming');
   return true;
}

function AltFire( float Value )
{
   ClientAltFire(Value);
}

function Fire( float Value )
{
   if ( (AmmoType == None) && (AmmoName != None) )
   {
      // ammocheck
      GiveAmmo(Pawn(Owner));
   }
   if ( AmmoType.UseAmmo(1) )
   {
      GotoState('NormalFire');
      bPointing=True;
      bCanClientFire = true;
      ClientFire(Value);
      if ( bRapidFire || (FiringSpeed > 0) )
         Pawn(Owner).PlayRecoil(FiringSpeed);
      if ( bInstantHit )
      {
         if ( (Owner.Physics != PHYS_Falling && Owner.Physics != PHYS_Swimming && Pawn(Owner).bDuck != 0)
            || Owner.Velocity == 0 * Owner.Velocity )
            TraceFire(0.0);
         else
            TraceFire(16);
      }
      else
         ProjectileFire(ProjectileClass, ProjectileSpeed, bWarnTarget);
   }
}

///////////////////////////////////////////////////////
state NormalFire
{
   function EndState()
   {
      Super.EndState();
      OldFlashCount = FlashCount;
   }

Begin:
      FlashCount++;
}

function Timer()
{
   local actor targ;
   local float bestAim, bestDist;
   local vector FireDir;
   local Pawn P;

   bestAim = 0.95;
   P = Pawn(Owner);
   if ( P == None )
   {
      GotoState('');
      return;
   }
   if ( VSize(P.Location - OwnerLocation) < 6 )
      StillTime += FMin(2.0, Level.TimeSeconds - StillStart);

   else
      StillTime = 0;
   StillStart = Level.TimeSeconds;
   OwnerLocation = P.Location;
   FireDir = vector(P.ViewRotation);
   targ = P.PickTarget(bestAim, bestDist, FireDir, Owner.Location);
   if ( Pawn(targ) != None )
   {
      SetTimer(1 + 4 * FRand(), false);
      bPointing = true;
      Pawn(targ).WarnTarget(P, 200, FireDir);
   }
   else
   {
      SetTimer(0.4 + 1.6 * FRand(), false);
      if ( (P.bFire == 0) && (P.bAltFire == 0) )
         bPointing = false;
   }
}

function ProcessTraceHit(Actor Other, Vector HitLocation, Vector HitNormal, Vector X, Vector Y, Vector Z)
{
	local UT_Shellcase s;

	s = Spawn(class'Beast_ShellCase',, '', Owner.Location + CalcDrawOffset() + 30 * X + (2.8 * FireOffset.Y+5.0) * Y - Z * 1);

	if ( s != None )
	{
		s.DrawScale = 0.85;
		s.Eject(((FRand()*0.3+0.4)*X + (FRand()*0.2+0.2)*Y + (FRand()*0.3+1.0) * Z)*160);
	}
	if (Other == Level)
		Spawn(class'UT_HeavyWallHitEffect',,, HitLocation+HitNormal, Rotator(HitNormal));
		
	else if ( (Other != self) && (Other != Owner) && (Other != None) )
	{
		if ( Other.bIsPawn )
			Other.PlaySound(Sound 'MDeath1',, 4.0,,100);
		if ( Other.bIsPawn && (HitLocation.Z - Other.Location.Z > 0.62 * Other.CollisionHeight)
			&& (instigator.IsA('PlayerPawn') || (instigator.IsA('Bot') && !Bot(Instigator).bNovice))
			&& ((Owner.Physics != PHYS_Falling && Owner.Physics != PHYS_Swimming && Pawn(Owner).bDuck != 0)
			   || Owner.Velocity == 0 * Owner.Velocity) )
			Other.TakeDamage(1000, Pawn(Owner), HitLocation, 35000 * X, AltDamageType);
		else
			Other.TakeDamage(500,  Pawn(Owner), HitLocation, 30000.0*X, MyDamageType);
		if ( !Other.bIsPawn && !Other.IsA('Carcass') )
			spawn(class'UT_SpriteSmokePuff',,,HitLocation+HitNormal*9);
		
	}
}

function Finish()
{
   if ( (Pawn(Owner).bFire!=0) && (FRand() < 0.6) )
      Timer();
   Super.Finish();
}

function TraceFire( float Accuracy )
{
   local vector HitLocation, HitNormal, StartTrace, EndTrace, X,Y,Z;
   local actor Other;
   local Pawn PawnOwner;

   PawnOwner = Pawn(Owner);

   Owner.MakeNoise(PawnOwner.SoundDampening);
   GetAxes(PawnOwner.ViewRotation,X,Y,Z);
   StartTrace = Owner.Location + PawnOwner.Eyeheight * Z;
   AdjustedAim = PawnOwner.AdjustAim(1000000, StartTrace, 2*AimError, False, False);
   EndTrace = StartTrace + Accuracy * (FRand() - 0.5 )* Y * 1000
      + Accuracy * (FRand() - 0.5 ) * Z * 1000;
   X = vector(AdjustedAim);
   EndTrace += (100000 * X);
   Other = PawnOwner.TraceShot(HitLocation,HitNormal,EndTrace,StartTrace);
   ProcessTraceHit(Other, HitLocation, HitNormal, X,Y,Z);
}


state Idle
{
   function Fire( float Value )
   {
      if ( AmmoType == None )
      {
         // ammocheck
         GiveAmmo(Pawn(Owner));
      }
      if (AmmoType.UseAmmo(1))
      {
         GotoState('NormalFire');
         bCanClientFire = true;
         bPointing=True;
         if ( Owner.IsA('Bot') )
         {
            // simulate bot using zoom
            if ( Bot(Owner).bSniping && (FRand() < 0.65) )
               AimError = AimError/FClamp(StillTime, 1.0, 8.0);
            else if ( VSize(Owner.Location - OwnerLocation) < 6 )
               AimError = AimError/FClamp(0.5 * StillTime, 1.0, 3.0);
            else
               StillTime = 0;
         }
         Pawn(Owner).PlayRecoil(FiringSpeed);
         if ( (Owner.Physics != PHYS_Falling && Owner.Physics != PHYS_Swimming && Pawn(Owner).bDuck != 0)
            || Owner.Velocity == 0 * Owner.Velocity )
            TraceFire(0.0);
         else
            TraceFire(16);
         AimError = Default.AimError;
         ClientFire(Value);
      }
   }


   function BeginState()
   {
      bPointing = false;
      SetTimer(0.4 + 1.6 * FRand(), false);
      Super.BeginState();
   }

   function EndState()
   {
      SetTimer(0.0, false);
      Super.EndState();
   }

Begin:
   bPointing=False;
   if ( AmmoType.AmmoAmount<=0 )
      Pawn(Owner).SwitchToBestWeapon();  //Goto Weapon that has Ammo
   if ( Pawn(Owner).bFire!=0 ) Fire(0.0);
   Disable('AnimEnd');
   PlayIdleAnim();
}

///////////////////////////////////////////////////////
state Zooming
{
   simulated function Tick(float DeltaTime)
   {
      if ( Pawn(Owner).bAltFire == 0 )
      {
         bZoom = false;
         SetTimer(0.0,False);
         GoToState('Idle');
      }
      else if ( bZoom )
      {
         if ( PlayerPawn(Owner).DesiredFOV > 3 )
         {
            PlayerPawn(Owner).DesiredFOV -= PlayerPawn(Owner).DesiredFOV*DeltaTime*4.5;
         }

         if ( PlayerPawn(Owner).DesiredFOV <=3 )
         {
            PlayerPawn(Owner).DesiredFOV = 3;
            bZoom = false;
            SetTimer(0.0,False);
            GoToState('Idle');
         }
      }
   }

   simulated function BeginState()
   {
      if ( Owner.IsA('PlayerPawn') )
      {
         if ( PlayerPawn(Owner).DesiredFOV == PlayerPawn(Owner).DefaultFOV )
         {
            bZoom = true;
            SetTimer(0.2,True);
         }
         else if ( bZoom == false )
         {
            PlayerPawn(Owner).DesiredFOV = PlayerPawn(Owner).DefaultFOV;
            Pawn(Owner).bAltFire = 0;
         }
      }
      else
      {
         Pawn(Owner).bFire = 1;
         Pawn(Owner).bAltFire = 0;
         Global.Fire(0);
      }
   }
}

///////////////////////////////////////////////////////////
simulated function PlayIdleAnim()
{
   if ( Mesh != PickupViewMesh )
      PlayAnim('Still',1.0, 0.05);
}

defaultproperties
{
    FireAnims(0)=Fire
    FireAnims(1)=Fire2
    FireAnims(2)=Fire3
    FireAnims(3)=Fire4
    FireAnims(4)=Fire5
    CColor=(R=255,G=255,B=255,A=0),
    WeaponDescription="Modified Sniper rifle."
    AmmoName=Class'CustomBullets'
    PickupAmmoCount=500
    bInstantHit=True
    bAltInstantHit=True
    FiringSpeed=1.80
    FireOffset=(X=0.00,Y=-5.00,Z=-2.00),
    MyDamageType=shot
    AltDamageType=Decapitated
    shakemag=400.00
    shaketime=0.15
    shakevert=8.00
    AIRating=0.54
    RefireRate=0.90
    AltRefireRate=0.30
    AltFireSound=Sound'UnrealShare.AutoMag.shot'
    DeathMessage="%k put a bullet through %o's head."
    NameColor=(R=0,G=0,B=255,A=0),
    MuzzleScale=1.00
    FlashY=0.11
    FlashO=0.01
    FlashC=0.03
    FlashLength=0.00
    FlashS=256
    MFTexture=Texture'Botpack.Rifle.MuzzleFlash2'
    AutoSwitchPriority=5
    InventoryGroup=10
    bRotatingPickup=False
    PickupMessage="You picked up the {Beast} Sniper Rifle."
    ItemName="Beast Sniper Rifle"
    PlayerViewOffset=(X=5.00,Y=-1.60,Z=-1.70),
    PlayerViewMesh=LodMesh'Botpack.Rifle2m'
    PlayerViewScale=2.00
    BobDamping=0.98
    PickupViewMesh=LodMesh'Pickupmeshp'
    ThirdPersonMesh=LodMesh'PickupmeshH'
    MuzzleFlashMesh=LodMesh'Botpack.muzzsr3'
    MuzzleFlashScale=0.10
    MuzzleFlashTexture=Texture'Botpack.Skins.Muzzy3'
    Rotation=(Pitch=0,Yaw=0,Roll=-1536),
    Mesh=LodMesh'Botpack.RifleHand'
    bNoSmooth=False
    CollisionRadius=32.00
    CollisionHeight=8.00
}
