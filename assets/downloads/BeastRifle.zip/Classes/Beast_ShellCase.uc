//=============================================================================
// Beast_ShellCase.
//=============================================================================
class Beast_ShellCase expands UT_ShellCase;

#EXEC texture IMPORT name=beast_Shellcase FILE=Textures\beast_Shellcase.bmp GROUP=Skins

defaultproperties
{
    MultiSkins(0)=Texture'Skins.Beast_ShellCase'
    MultiSkins(1)=Texture'Skins.Beast_ShellCase'
    MultiSkins(2)=Texture'Skins.Beast_ShellCase'
    MultiSkins(3)=Texture'Skins.Beast_ShellCase'
    MultiSkins(4)=Texture'Skins.Beast_ShellCase'
    MultiSkins(5)=Texture'Skins.Beast_ShellCase'
    MultiSkins(6)=Texture'Skins.Beast_ShellCase'
    MultiSkins(7)=Texture'Skins.Beast_ShellCase'
}
