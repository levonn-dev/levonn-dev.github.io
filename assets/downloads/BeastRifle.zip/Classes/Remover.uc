//=============================================================================
// Remover.
//=============================================================================

class Remover expands Mutator config(BeastRifle);

var() config localized bool
	bRemoveInvis,			 //Invisibility
	bRemoveStealth,			 //Stealth
	bRemoveUdamage,			 //Damage Amplifier
    bRemoveThighPads,        //ThighPads
	bRemoveArmor2,           //Armor
	bRemoveUTShieldBelt,	 //Shield Belt
	bRemoveKevlarSuit,       //Kevlar Suit
	bRemoveAsbestosSuit,     //Asbestos Suit
	bRemoveToxinSuit,        //Toxin Suit
	bRemoveForceField,       //Force Field
    bRemoveUT_Jumpboots,     //Jump Boots
    bRemoveSearchLight,      //Search Light
	bRemoveFlashlight,       //FlashLight
    bRemoveSCUBAGear,        //ScubaGear
	bRemoveHealthVial,		 //HealthVial
	bRemoveMedBox,			 //Medic Box
	bRemoveHealthPack,		 //Health Pack
	bRemoveNaliFruit;        //Nali Fruit



function bool CheckReplacement(Actor Other, out byte bSuperRelevant)
{
	If ( Other.IsA('UT_invisibility') && bRemoveInvis )
        return false;

	If ( Other.IsA('UT_Stealth') && bRemoveStealth )
        return false;

	If ( Other.IsA('Udamage') && bRemoveUdamage )
        return false;

	If ( Other.IsA('ThighPads') && bRemoveThighPads )
        return false;

	If ( Other.IsA('Armor2') && bRemoveArmor2 )
        return false;

	If ( Other.IsA('UT_ShieldBelt') && bRemoveUTShieldBelt )
        return false;

	If ( Other.IsA('KevlarSuit') && bRemoveKevlarSuit )
        return false;

	If ( Other.IsA('AsbestosSuit') && bRemoveAsbestosSuit )
        return false;

	If ( Other.IsA('ToxinSuit') && bRemoveToxinSuit )
        return false;

	If ( Other.IsA('ForceField') && bRemoveForceField )
        return false;

	If ( Other.IsA('UT_Jumpboots') && bRemoveUT_Jumpboots )
        return false;

	If ( Other.IsA('SearchLight') && bRemoveSearchLight )
        return false;

	If ( Other.IsA('Flashlight') && bRemoveFlashlight )
        return false;

	If ( Other.IsA('ScubaGear') && bRemoveSCUBAGear )
        return false;

	If ( Other.IsA('HealthVial') && bRemoveHealthVial )
		return false;

	If ( Other.IsA('MedBox') && bRemoveMedBox )
		return false;

	If ( Other.IsA('HealthPack') && bRemoveHealthPack )
		return false;

	If ( Other.IsA('NaliFruit') && bRemoveNaliFruit )
		return false;

	return true;
}

defaultproperties
{
    bRemoveInvis=True
    bRemoveStealth=True
    bRemoveUdamage=True
    bRemoveThighPads=True
    bRemoveArmor2=True
    bRemoveUTShieldBelt=True
    bRemoveKevlarSuit=True
    bRemoveAsbestosSuit=True
    bRemoveToxinSuit=True
    bRemoveForceField=True
    bRemoveUT_Jumpboots=True
    bRemoveSearchLight=True
    bRemoveFlashlight=True
    bRemoveSCUBAGear=True
    bRemoveHealthVial=True
    bRemoveMedBox=True
    bRemoveHealthPack=True
    bRemoveNaliFruit=True
}
