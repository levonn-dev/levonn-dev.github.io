///////////////////////////////////////
//
//   Rifle pickup and third person
//   view mesh
//
//     by:  :[lol]:WalknBullseye
//           using this mesh allows the the ability to change
//           the third person view and the pickup view textures
//           without changing the hand texture in first person view.
//           this was done by remaking the rifle pickup model and
//           renaming the multiskin id's
//           MultiSkins(5) is the multiskin id#
////////////////////////////////////////

class PickUpMesh extends actor;

#exec mesh IMPORT mesh=Pickupmeshp ANIVFILE=MODELS\lolriflepick_a.3D DATAFILE=MODELS\lolriflepick_d.3D X=0 Y=0 Z=0
#exec mesh ORIGIN mesh=Pickupmeshp X=0 Y=0 Z=0 YAW=64
#exec mesh SEQUENCE MESH=Pickupmeshp SEQ=All         STARTFRAME=0   NUMFRAMES=1
#exec mesh SEQUENCE MESH=Pickupmeshp SEQ=Still        STARTFRAME=0   NUMFRAMES=1
#exec texture IMPORT name=rifletex FILE=Textures\multi.pcx GROUP=Skins LODSET=2
#exec MESHMAP scale MESHMAP=Pickupmeshp X=0.07 Y=0.07 Z=0.17

#exec MESHMAP SETTEXTURE MESHMAP=PickupmeshP NUM=5 TEXTURE=rifletex

#exec mesh IMPORT mesh=PickupmeshH ANIVFILE=MODELS\lolriflepick_a.3D DATAFILE=MODELS\lolriflepick_d.3D X=0 Y=0 Z=0
#exec mesh ORIGIN mesh=PickupmeshH X=-150 Y=0 Z=-30 YAW=255 PITCH=0 ROLL=0
#exec mesh SEQUENCE MESH=PickupmeshH SEQ=All  STARTFRAME=0  NUMFRAMES=1
#exec MESHMAP scale MESHMAP=PickupmeshH X=0.07 Y=0.07 Z=0.14

#exec MESHMAP SETTEXTURE MESHMAP=Pickupmeshh NUM=5 TEXTURE=rifletex

defaultproperties
{
}
