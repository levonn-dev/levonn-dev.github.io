////////////////////////////////////////////////////////////////////////////////

//   CustomArena

//

//   Replaces all game weapons/ammo with custom weapon/ammo, and changes the

//   default weapon from the impact hammer to the translocator.

//

//   This code combines elements of the standard Arena mutator with common

//   weapon swapper code found in most zark and clan sniper rifles, which (to my

//   knowledge) was created by SpawnKiller/SkullKrusher.

//

//   Authored by :[lol]:Mhor of www.teamlol.com

//

////////////////////////////////////////////////////////////////////////////////

class CustomArena extends Mutator;



var   name   WeaponName,         //The name of our custom weapon.
             AmmoName;
                    //The name of our custom ammo.

var   string   WeaponString,      //The string Package.Class name of our custom weapon.
               AmmoString;
                      //The string Package.class name of our custom ammo.



//Set the level's default weapon prior to gameplay.

event PreBeginPlay()

{
   Level.Game.DefaultWeapon=class'BeastRifle.StealthTrans';
}

function ModifyPlayer(Pawn Other)

{

   //Give the player our custom weapon.

   DeathMatchPlus(Level.Game).GiveWeapon(Other,WeaponString);



   //Never break the chain, baby.

   if(NextMutator != None)

      NextMutator.ModifyPlayer(Other);

}

function bool AlwaysKeep(Actor Other)

{

   if(Other.IsA('Enforcer') || Other.IsA('ImpactHammer'))

      return false;



   //If our custom weapon is being spawned...

   if(Other.IsA(WeaponName))

   {

      Weapon(Other).PickupAmmoCount=Weapon(Other).Default.PickUpAmmoCount;

      return true;

   }

   //If our custom ammo is being spawned...

   if(Other.IsA(AmmoName))

   {

      Ammo(Other).AmmoAmount=Ammo(Other).AmmoAmount;

      return true;

   }



   //If the object is not a custom weapon/ammo, then consult the next mutator.

   if(NextMutator != None)

      return(NextMutator.AlwaysKeep(Other));

   return false;

}

function bool CheckReplacement(Actor Other, out byte bSuperRelevant)

{

   //If a weapon is being spawned...

   if (Other.IsA('Weapon'))

   {

      if(Other.IsA('Enforcer') || Other.IsA('ImpactHammer'))

         return false;

      else if(Other.IsA('Translocator'))

         return true;

      else

      {

         if(WeaponString=="")

            return false;

         else if (!Other.IsA(WeaponName))

         {

            ReplaceWith(Other,WeaponString);

            return false;

         }

      }

   }

   //If a ammo is being spawned...

   if(Other.IsA('Ammo'))

   {

      if(AmmoString=="")

         return false;

      else if (!Other.IsA(AmmoName))

      {

         ReplaceWith(Other,AmmoString);

         return false;

      }

   }

        

   return true;

}

defaultproperties
{
    WeaponName=CustomSniperRifle
    AmmoName=CustomBullets
    WeaponString="BeastRifle.CustomSniperRifle"
    AmmoString="BeastRifle.CustomBullets"
}
